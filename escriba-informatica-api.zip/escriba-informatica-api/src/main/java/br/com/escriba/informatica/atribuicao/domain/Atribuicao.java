package br.com.escriba.informatica.atribuicao.domain;

import br.com.escriba.informatica.cartorio.domain.Cartorio;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(name = "unique_atribuicao", columnNames = {"id", "nome"} ))
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Atribuicao {

    @Id
    @Column(name = "id", nullable = false, length = 20)
    private String id;

    @Column
    private String nome;

    @Column
    private boolean situacao = true;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cartorio_id")
    private Cartorio cartorio;

}
