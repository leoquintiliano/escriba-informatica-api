package br.com.escriba.informatica.atribuicao.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AtribuicaoDTO {

    @NotBlank(message = "Campo id é obrigatório")
    @Length(max = 20)
    private String id;

    @Pattern(regexp = "^[A-Z]+(.)*", message = "Campo nome deve iniciar com letra maiúscula")
    @NotBlank(message = "Campo nome é obrigatório")
    @Length(max = 50)
    private String nome;

    @NotNull(message = "Campo situação é obrigatório")
    private boolean situacao = true;

}
