package br.com.escriba.informatica.atribuicao.mapper;

import br.com.escriba.informatica.atribuicao.domain.Atribuicao;
import br.com.escriba.informatica.atribuicao.dto.AtribuicaoDTO;
import br.com.escriba.informatica.atribuicao.dto.AtribuicaoSimplesDTO;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.stream.Collectors;

@Service
public class AtribuicaoMapper {

    public static AtribuicaoDTO toDTO(Atribuicao atribuicao) {
        return AtribuicaoDTO.builder()
                .id(atribuicao.getId())
                .nome(atribuicao.getNome())
                .situacao(atribuicao.isSituacao())
                .build();
    }

    public static Atribuicao toEntity(AtribuicaoDTO atribuicaoDTO) {
        return Atribuicao.builder()
                .id(atribuicaoDTO.getId())
                .nome(atribuicaoDTO.getNome())
                .situacao(atribuicaoDTO.isSituacao())
                .build();
    }

    public Collection<Atribuicao> toCollection(Collection<AtribuicaoDTO> atribuicoes) {
        return atribuicoes
                .stream()
                .map( elem -> this.toEntity(elem))
                .collect(Collectors.toSet());
    }

    public Collection<AtribuicaoDTO> toCollectionDTO(Collection<Atribuicao> atribuicoes) {
        return atribuicoes
                .stream()
                .map( elem -> this.toDTO(elem))
                .collect(Collectors.toList());
    }

    public static AtribuicaoSimplesDTO toSimplesDTO(Atribuicao atribuicao) {
        return AtribuicaoSimplesDTO
                .builder()
                .id(atribuicao.getId())
                .nome(atribuicao.getNome())
                .build();
    }

}
