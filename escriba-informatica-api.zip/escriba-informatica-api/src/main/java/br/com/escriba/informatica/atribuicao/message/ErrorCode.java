package br.com.escriba.informatica.atribuicao.message;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.HashMap;

@Getter
@AllArgsConstructor
public enum ErrorCode {

    NAME_REQUIRED("error.component.atribuicao.name.required", "[Atribuicao] Atribuicao, o campo name é obrigatório"),
    EXISTING_ID("error.component.atribuicao.id.already.exists", "Registro já cadastrado"),
    EXISTING_NAME("error.component.atribuicao.name.already.exists", "Nome já informado no registro com código "),
    HAS_ASSOCIATED("error.component.has.associated.cartorios", "[Cartorio] Registro utilizado em outro cadastro.”"),
    CODE_NOT_FOUND("error.atribuicao.code.not-found", "[Atribuicao] Code not found."),
    CODE_DUPLICATED("error.atribuicao.code.duplicated", "[Atribuicao] Registro já cadastrado");

    private String key;
    private String description;

    public HashMap<String, String> getMssage( ) {
        var errors = new HashMap<String,String>();
        errors.put(key, description);
        return errors;
    }

}
