package br.com.escriba.informatica.atribuicao.repository;

import br.com.escriba.informatica.atribuicao.domain.Atribuicao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AtribuicaoRepository extends JpaRepository<Atribuicao, String>, JpaSpecificationExecutor<Atribuicao> {

    Optional<Atribuicao> findByNome(String nome);

    Optional<Atribuicao> findAtribuicaoById(String id);


//    @Query(value = "SELECT COUNT(a.id) FROM Atribuicao a WHERE a.cartorio.id = :id" , nativeQuery = false)
    @Query(value = "SELECT COUNT(a.id) FROM atribuicao a LEFT JOIN cartorio c ON a.cartorio_id = c.id WHERE c.id = :id", nativeQuery = true)
    Long countByCartorio(@Param("id") Long id);

}
