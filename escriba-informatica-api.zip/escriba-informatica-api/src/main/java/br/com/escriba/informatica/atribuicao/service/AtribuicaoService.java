package br.com.escriba.informatica.atribuicao.service;

import br.com.escriba.informatica.atribuicao.domain.Atribuicao;
import br.com.escriba.informatica.atribuicao.dto.AtribuicaoDTO;
import br.com.escriba.informatica.atribuicao.dto.AtribuicaoSimplesDTO;
import br.com.escriba.informatica.atribuicao.mapper.AtribuicaoMapper;
import br.com.escriba.informatica.atribuicao.message.ErrorCode;
import br.com.escriba.informatica.atribuicao.repository.AtribuicaoRepository;
import br.com.escriba.informatica.exception.AtribuicaoException;
import br.com.escriba.informatica.utils.HandleError;
import br.com.escriba.informatica.utils.PagedResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class AtribuicaoService {

    @Autowired
    private AtribuicaoRepository atribuicaoRepository;

    @Autowired
    private AtribuicaoMapper atribuicaoMapper;

    public AtribuicaoDTO salvar(AtribuicaoDTO atribuicaoDTO) {
        var response = atribuicaoRepository.save(this.atribuicaoMapper.toEntity(atribuicaoDTO));
        return atribuicaoMapper.toDTO(response);
    }

    public PagedResponse findById(String id, Pageable pageable) {
        var atribuicao = atribuicaoRepository.findById(id).orElseThrow( () -> new AtribuicaoException(""));
        var page = PageableExecutionUtils.getPage(List.of(atribuicao), pageable,List.of(atribuicao)::size);
        return this.getPagedAtribuicoes(false,pageable,page);
    }

    public Atribuicao getAtribuicao(String id) {
        return atribuicaoRepository.findAtribuicaoById(id).orElseThrow( () -> new AtribuicaoException("Nenhuma atribuicao encontrada!") );
    }

    public PagedResponse listar(boolean thin, Pageable pageable) {
        var atribuicaoList = atribuicaoRepository.findAll();
        var atribuicaoPage = PageableExecutionUtils.getPage(atribuicaoList, pageable,atribuicaoList::size);
        return this.getPagedAtribuicoes(thin,pageable,atribuicaoPage);
    }

    private PagedResponse getPagedAtribuicoes(boolean thin, Pageable pageable, Page page) {
        return !thin ? new PagedResponse(new PageImpl<AtribuicaoDTO>(this.listStandardAtribuicoes(page.toList()), pageable, page.getTotalElements()))
                :  new PagedResponse(new PageImpl<AtribuicaoSimplesDTO>(this.listSimpleViewAtribuicoeseDTO(page.toList()), pageable, page.getTotalElements()));
    }

    private List<AtribuicaoSimplesDTO> listSimpleViewAtribuicoeseDTO(List<Atribuicao> atribuicoes) {
        return atribuicoes
                .stream()
                .map( AtribuicaoMapper::toSimplesDTO)
                .collect(Collectors.toList());
    }

    private List<AtribuicaoDTO> listStandardAtribuicoes(List<Atribuicao> atribuicoes) {
        return atribuicoes
                .stream()
                .map(AtribuicaoMapper::toDTO)
                .collect(Collectors.toList());
    }

    public AtribuicaoDTO editar(String id, AtribuicaoDTO atribuicaoDTO) {
        var atribuicao = atribuicaoRepository.findAtribuicaoById(id).orElseThrow( () -> new AtribuicaoException("Nenhuma atribuicao encontrada!") );
        this.validateBeforeUpdate(atribuicaoDTO, atribuicao);
        var atribuicaoToBeUpdated = this.atribuicaoMapper.toEntity(atribuicaoDTO);
        atribuicao = this.atribuicaoRepository.save(atribuicaoToBeUpdated);
        return this.atribuicaoMapper.toDTO(atribuicao);
    }

    public void deletar(String id) {
        var atribuicao = this.getAtribuicao(id);
        if(atribuicao.getCartorio() != null && atribuicao.getCartorio().getId() != null) {
            Long amountOfCartorios = this.getAmountOfCartorios(atribuicao.getCartorio().getId());
            if (amountOfCartorios != null && amountOfCartorios > 0) {
                throw new AtribuicaoException(ErrorCode.HAS_ASSOCIATED.getDescription());
            }
        }
        atribuicaoRepository.delete(atribuicao);
    }

    private Long getAmountOfCartorios(Long id) {
        return this.atribuicaoRepository.countByCartorio(id);
    }

    private Long getAmountOfAtribuicoesById(String id) {
        return this.atribuicaoRepository.findAtribuicaoById(id).stream().count();
    }

    private Long getAmountOfAtribuicoesByName(String nome) {
        return this.atribuicaoRepository.findByNome(nome).stream().count() ;
    }

    private void validateBeforeUpdate(AtribuicaoDTO atribuicaoDTO, Atribuicao atribuicao) {
        if(Objects.nonNull(atribuicao) && this.getAmountOfAtribuicoesByName(atribuicaoDTO.getNome()) > 0) {
            var exception = HandleError.getInstance().handleErrorMessage(atribuicaoDTO.getNome(),"NOME");
            throw exception;
        }
    }

}
