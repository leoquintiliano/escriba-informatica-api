package br.com.escriba.informatica.cartorio.controller;

import br.com.escriba.informatica.cartorio.dto.CartorioDTO;
import br.com.escriba.informatica.cartorio.service.CartorioService;
import br.com.escriba.informatica.utils.PagedResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;


@RestController
@RequestMapping("/api/cartorio")
public class CartorioController {

    @Autowired
    private CartorioService cartorioService;

    @PostMapping
    private ResponseEntity<?> salvar(@RequestBody @Valid CartorioDTO cartorioDTO) {
        var response = cartorioService.salvar(cartorioDTO);
        return ResponseEntity.ok().body(response);
    }

    @PutMapping("/editar/{id}")
    private ResponseEntity<CartorioDTO> editar(@PathVariable("id") Long id, @RequestBody @Valid CartorioDTO cartorioDTO) {
        var response = this.cartorioService.editar(id,cartorioDTO);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/deletar/{id}")
    private ResponseEntity<?> deletar(@PathVariable("id") Long id) {
        this.cartorioService.deletar(id);
        return ResponseEntity.ok("Registro deletado com sucesso!");
    }

    @GetMapping("/listar/completo")
    public PagedResponse listar(@RequestParam(name = "thin", required = false) boolean thin,
                                @PageableDefault(sort = "id", direction = Sort.Direction.ASC) Pageable pageable ) {
        return this.cartorioService.listar(thin, pageable);
    }

    @GetMapping("/listar/resumido")
    public PagedResponse listarSimples(@RequestParam(name = "thin", required = false) boolean thin,
                                       @PageableDefault(sort = "id", direction = Sort.Direction.ASC) Pageable pageable ) {
        return this.cartorioService.listar(false, pageable);
    }

    @GetMapping("/visualizar")
    public PagedResponse view(@PathVariable Long id,@PageableDefault(sort = "id", direction = Sort.Direction.ASC) Pageable pageable) {
        return this.cartorioService.findById(id,pageable);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String,String> handleValidationException(MethodArgumentNotValidException exception) {
        Map<String, String> errors = new HashMap<>();
        exception.getBindingResult().getAllErrors().forEach( (error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorDefaultMessage = error.getDefaultMessage();
            errors.put(fieldName, errorDefaultMessage);
        });
        return errors;
    }

}
