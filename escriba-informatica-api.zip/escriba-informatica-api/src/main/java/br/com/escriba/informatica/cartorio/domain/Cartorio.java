package br.com.escriba.informatica.cartorio.domain;

import br.com.escriba.informatica.atribuicao.domain.Atribuicao;
import br.com.escriba.informatica.enums.SituacaoCartorioEnum;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import java.util.Collection;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(name = "unique_cartorio", columnNames = {"id", "nome"} ))
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Cartorio {

    @Id
    @Column(name = "id", nullable = false)
    @NotNull
    private Long id;

    @Column
    private String nome;

    @Column
    private String observacao;

    @Enumerated(EnumType.STRING)
    @Column(name = "situacao")
    private SituacaoCartorioEnum situacaoCartorio;

    @OneToMany(mappedBy = "cartorio", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY, targetEntity = Atribuicao.class)
    private Collection<Atribuicao> atribuicoes;

}
