package br.com.escriba.informatica.cartorio.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CartorioSimplesDTO {

    private Long id;

    private String nome;

}
