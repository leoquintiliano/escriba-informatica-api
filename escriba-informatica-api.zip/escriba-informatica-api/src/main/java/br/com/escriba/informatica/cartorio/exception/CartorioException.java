package br.com.escriba.informatica.cartorio.exception;

public class CartorioException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public CartorioException(String message) {
        super(message);
    }

}
