package br.com.escriba.informatica.cartorio.mapper;

import br.com.escriba.informatica.atribuicao.mapper.AtribuicaoMapper;
import br.com.escriba.informatica.cartorio.domain.Cartorio;
import br.com.escriba.informatica.cartorio.dto.CartorioDTO;
import br.com.escriba.informatica.cartorio.dto.CartorioSimplesDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CartorioMapper {

//    @Autowired
    private static AtribuicaoMapper atribuicaoMapper;

    public CartorioMapper(AtribuicaoMapper atribuicaoMapper) {
        this.atribuicaoMapper = atribuicaoMapper;
    }

    public static CartorioDTO toDTO(Cartorio cartorio) {
        return CartorioDTO.builder()
                .id(cartorio.getId())
                .nome(cartorio.getNome())
                .atribuicoes(atribuicaoMapper.toCollectionDTO(cartorio.getAtribuicoes()))
                .situacaoCartorio(cartorio.getSituacaoCartorio())
                .build();
    }

    public static Cartorio toEntity(CartorioDTO cartorioDTO) {
        return Cartorio.builder()
                .id(cartorioDTO.getId())
                .nome(cartorioDTO.getNome())
                .situacaoCartorio(cartorioDTO.getSituacaoCartorio())
                .atribuicoes(atribuicaoMapper.toCollection(cartorioDTO.getAtribuicoes()))
                .situacaoCartorio(cartorioDTO.getSituacaoCartorio())
                .build();
    }

    public static CartorioSimplesDTO toSimplesDTO(Cartorio cartorio) {
        return CartorioSimplesDTO
                .builder()
                .id(cartorio.getId())
                .nome(cartorio.getNome())
                .build();
    }

}
