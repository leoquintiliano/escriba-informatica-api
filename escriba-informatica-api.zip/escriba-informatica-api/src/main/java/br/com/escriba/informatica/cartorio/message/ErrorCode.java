package br.com.escriba.informatica.cartorio.message;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.HashMap;

@Getter
@AllArgsConstructor
public enum ErrorCode {


    NAME_REQUIRED("error.component.cartorio.name.required", "[Cartorio] Cartorio, o campo name é obrigatório"),
    EXISTING_ID("error.component.cartorio.id.already.exists", "Registro já cadastrado"),
    EXISTING_NAME("error.component.cartorio.name.already.exists", "Nome já informado no registro com código "),
    HAS_ASSOCIATED("error.component.has.cartorio.cartorios", "[Cartorio] Registro utilizado em outro cadastro.”"),
    CODE_NOT_FOUND("error.cartorio.code.not-found", "[Cartorio] Code not found."),
    CODE_DUPLICATED("error.cartorio.code.duplicated", "[Cartorio] Registro já cadastrado");

    private String key;
    private String description;

    public HashMap<String, String> getMssage( ) {
        var errors = new HashMap<String,String>();
        errors.put(key, description);
        return errors;
    }

}
