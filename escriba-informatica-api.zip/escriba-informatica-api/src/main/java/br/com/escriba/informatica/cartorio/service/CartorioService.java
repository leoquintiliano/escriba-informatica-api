package br.com.escriba.informatica.cartorio.service;

import br.com.escriba.informatica.atribuicao.domain.Atribuicao;
import br.com.escriba.informatica.atribuicao.dto.AtribuicaoDTO;
import br.com.escriba.informatica.atribuicao.mapper.AtribuicaoMapper;
import br.com.escriba.informatica.atribuicao.service.AtribuicaoService;
import br.com.escriba.informatica.cartorio.domain.Cartorio;
import br.com.escriba.informatica.cartorio.dto.CartorioDTO;
import br.com.escriba.informatica.cartorio.dto.CartorioSimplesDTO;
import br.com.escriba.informatica.cartorio.exception.CartorioException;
import br.com.escriba.informatica.cartorio.mapper.CartorioMapper;
import br.com.escriba.informatica.cartorio.repository.CartorioRepository;
import br.com.escriba.informatica.utils.HandleError;
import br.com.escriba.informatica.utils.PagedResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class CartorioService {
    
    @Autowired
    private CartorioRepository cartorioRepository;

    @Autowired
    private CartorioMapper cartorioMapper;

    public CartorioDTO salvar(CartorioDTO cartorioDTO) {
        var response = cartorioRepository.save(this.cartorioMapper.toEntity(cartorioDTO));
        return cartorioMapper.toDTO(response);
    }

    public PagedResponse findById(Long id, Pageable pageable) {
        var cartorio = this.getCartorio(id);
        var page = PageableExecutionUtils.getPage(List.of(cartorio), pageable,List.of(cartorio)::size);
        return this.getPagedCartorios(false,pageable,page);
    }

    public Cartorio getCartorio(Long id) {
        return cartorioRepository.findById(id).orElseThrow( () -> new CartorioException("Nenhum catrório encontrado!") );
    }

    public PagedResponse listar(boolean thin, Pageable pageable) {
        var cartorios = cartorioRepository.findAll();
        var page = PageableExecutionUtils.getPage(cartorios, pageable,cartorios::size);
        return this.getPagedCartorios(thin,pageable,page);
    }

    private PagedResponse getPagedCartorios(boolean thin, Pageable pageable, Page page) {
        return !thin ? new PagedResponse(new PageImpl<CartorioDTO>(this.listStandardCartorios(page.toList()), pageable, page.getTotalElements()))
                :  new PagedResponse(new PageImpl<CartorioSimplesDTO>(this.listSimpleViewCartoriosDTO(page.toList()), pageable, page.getTotalElements()));
    }

    private List<CartorioDTO> listStandardCartorios(List<Cartorio> cartorios) {
        return cartorios
                .stream()
                .map(CartorioMapper::toDTO)
                .collect(Collectors.toList());
    }

    private List<CartorioSimplesDTO> listSimpleViewCartoriosDTO(List<Cartorio> cartorios) {
        return cartorios
                .stream()
                .map(CartorioMapper::toSimplesDTO)
                .collect(Collectors.toList());
    }

    public CartorioDTO editar(Long id, CartorioDTO cartorioDTO) {
        var cartorio = cartorioRepository.findById(id).orElseThrow( () -> new CartorioException("Nenhum cartório encontrado para ser editado!") );
        this.validateBeforeUpdate(cartorioDTO,cartorio,this.getAmountOfCartorios(cartorio.getId()));
        var cartorioToBeUpdated = this.cartorioMapper.toEntity(cartorioDTO);
        cartorio = this.cartorioRepository.save(cartorioToBeUpdated);
        return this.cartorioMapper.toDTO(cartorio);
    }

    public void deletar(Long id) {
        cartorioRepository.deleteById(id);
    }

    private Long getAmountOfCartorios(Long id) {
        return this.cartorioRepository.countById(id);
    }

    private Long getAmountOfCartoriosByName(String nome) {
        return this.cartorioRepository.findByNome(nome).stream().count() ;
    }

    private void validateBeforeUpdate(CartorioDTO cartorioDTO, Cartorio cartorio, Long amountOfCartorios) {
        if(Objects.nonNull(cartorio) && amountOfCartorios > 0) {
            var exception = HandleError.getInstance().handleErrorMessage(cartorioDTO.getId().toString(),"ID");
            throw exception;
        }

        if(Objects.nonNull(cartorio) && this.getAmountOfCartoriosByName(cartorioDTO.getNome()) > 0) {
            var exception = HandleError.getInstance().handleErrorMessage(cartorioDTO.getNome(),"NOME");
            throw exception;
        }
    }

}
