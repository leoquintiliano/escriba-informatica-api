package br.com.escriba.informatica.enums;

public enum SituacaoCartorioEnum {

    SIT_ATIVO("Ativo"),
    SIT_BLOQUEADO("Bloqueado");

    private String descricao;

    public String getDescricao() {
        return descricao;
    }

    SituacaoCartorioEnum(String descricao) {
        this.descricao = descricao;
    }

}
