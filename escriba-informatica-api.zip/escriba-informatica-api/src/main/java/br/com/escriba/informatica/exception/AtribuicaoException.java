package br.com.escriba.informatica.exception;

public class AtribuicaoException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public AtribuicaoException(String message) {
        super(message);
    }

}
