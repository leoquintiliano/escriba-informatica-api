package br.com.escriba.informatica.situacao.controller;

import br.com.escriba.informatica.situacao.dto.SituacaoDTO;
import br.com.escriba.informatica.situacao.service.SituacaoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/situacao")
public class SituacaoController {

    @Autowired
    private SituacaoService situacaoService;

    @PostMapping("/salvar")
    private ResponseEntity<?> salvar(@RequestBody @Valid SituacaoDTO situacaoDTO) {
        situacaoService.salvar(situacaoDTO);
        return ResponseEntity.ok("Registro adicionado com sucesso! => " + situacaoDTO.getNome());
    }

    @PutMapping("/editar/{id}")
    private ResponseEntity<SituacaoDTO> editar(@PathVariable("id") String id, @RequestBody @Valid SituacaoDTO situacaoDTO) {
        var response = this.situacaoService.editar(id,situacaoDTO);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/deletar/{id}")
    private ResponseEntity<?> deletar(@PathVariable("id") String id) {
        this.situacaoService.deletar(id);
        return ResponseEntity.ok("Registro deletado com sucesso!");
    }

    @GetMapping
    public ResponseEntity<?> listar(@PageableDefault(sort = "id", direction = Sort.Direction.ASC) Pageable pageable ) {
        return ResponseEntity.ok(this.situacaoService.listar(pageable));
    }

    @GetMapping("/visualizar/{id}")
    public ResponseEntity<?> view(@PathVariable String id, @PageableDefault(sort = "id", direction = Sort.Direction.ASC) Pageable pageable ) {
        return ResponseEntity.ok(this.situacaoService.findById(id,pageable));
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String,String> handleValidationException(MethodArgumentNotValidException exception) {
        Map<String, String> errors = new HashMap<>();
        exception.getBindingResult().getAllErrors().forEach( (error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorDefaultMessage = error.getDefaultMessage();
            errors.put(fieldName, errorDefaultMessage);
        });
        return errors;
    }

}
