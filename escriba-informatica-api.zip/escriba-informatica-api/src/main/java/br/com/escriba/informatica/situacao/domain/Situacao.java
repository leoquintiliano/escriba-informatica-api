package br.com.escriba.informatica.situacao.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(uniqueConstraints = {@UniqueConstraint(name = "unique_name",columnNames = "nome"), @UniqueConstraint(name = "unique_situacao", columnNames = {"id", "nome"} )} )
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Situacao {

    @Id
    @Column(name = "id", nullable = false, length = 20)
    private String id;

    @Column
    private String nome;

}
