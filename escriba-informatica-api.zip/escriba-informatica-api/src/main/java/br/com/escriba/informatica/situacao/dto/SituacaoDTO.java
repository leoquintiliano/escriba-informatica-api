package br.com.escriba.informatica.situacao.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SituacaoDTO {

    @NotNull
    @Length(min = 1, max = 20)
    private String id;

    @NotBlank(message = "Campo nome não informado")
    @Length(max = 50)
    private String nome;



}
