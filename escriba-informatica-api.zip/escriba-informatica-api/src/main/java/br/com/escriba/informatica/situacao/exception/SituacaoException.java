package br.com.escriba.informatica.situacao.exception;

public class SituacaoException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public SituacaoException(String message) {
        super(message);
    }

}
