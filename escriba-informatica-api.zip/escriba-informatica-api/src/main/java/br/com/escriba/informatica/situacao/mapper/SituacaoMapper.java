package br.com.escriba.informatica.situacao.mapper;

import br.com.escriba.informatica.situacao.domain.Situacao;
import br.com.escriba.informatica.situacao.dto.SituacaoDTO;
import org.springframework.stereotype.Component;

@Component
public class SituacaoMapper {

    public static SituacaoDTO toDTO(Situacao situacao) {
        return SituacaoDTO.builder()
                .id(situacao.getId())
                .nome(situacao.getNome())
                .build();
    }

    public static Situacao toEntity(SituacaoDTO situacaoDTO) {
        return Situacao.builder()
                .id(situacaoDTO.getId())
                .nome(situacaoDTO.getNome())
                .build();
    }

}
