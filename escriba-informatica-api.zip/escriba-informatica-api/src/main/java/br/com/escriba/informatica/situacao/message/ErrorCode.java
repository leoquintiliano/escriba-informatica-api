package br.com.escriba.informatica.situacao.message;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.HashMap;

@Getter
@AllArgsConstructor
public enum ErrorCode {

    NAME_REQUIRED("error.component.situacao.name.required", "[Situação] Atribuicao, o campo name é obrigatório"),
    EXISTING_ID("error.component.situacao.id.already.exists", "Registro já cadastrado"),
    EXISTING_NAME("error.component.situacao.name.already.exists", "Nome já informado no registro com código "),
    HAS_ASSOCIATED("error.component.has.associated.cartorios", "[Cartorio] Registro utilizado em outro cadastro.”"),
    CODE_NOT_FOUND("error.situacao.code.not-found", "[Situação] Code not found."),
    CODE_DUPLICATED("error.situacao.code.duplicated", "[Situação] Registro já cadastrado");

    private String key;
    private String description;

    public HashMap<String, String> getMssage( ) {
        var errors = new HashMap<String,String>();
        errors.put(key, description);
        return errors;
    }

}
