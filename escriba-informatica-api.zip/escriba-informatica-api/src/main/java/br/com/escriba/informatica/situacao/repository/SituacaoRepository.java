package br.com.escriba.informatica.situacao.repository;

import br.com.escriba.informatica.situacao.domain.Situacao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SituacaoRepository extends JpaRepository<Situacao, String>, JpaSpecificationExecutor<Situacao> {

    Optional<Situacao> findByNome(String nome);

    @Query(value = "SELECT COUNT(c.id) FROM Cartorio c WHERE c.situacao = :situacao ", nativeQuery = true)
    Long countCartoriosBySituacao(@Param("situacao") String situacao);
}
