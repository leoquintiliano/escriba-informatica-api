package br.com.escriba.informatica.situacao.service;

import br.com.escriba.informatica.cartorio.exception.CartorioException;
import br.com.escriba.informatica.situacao.message.ErrorCode;
import br.com.escriba.informatica.situacao.exception.SituacaoException;
import br.com.escriba.informatica.situacao.domain.Situacao;
import br.com.escriba.informatica.situacao.dto.SituacaoDTO;
import br.com.escriba.informatica.situacao.mapper.SituacaoMapper;
import br.com.escriba.informatica.situacao.repository.SituacaoRepository;
import br.com.escriba.informatica.utils.HandleError;
import br.com.escriba.informatica.utils.PagedResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class SituacaoService {

    @Autowired
    private SituacaoRepository situacaoRepository;

    @Autowired
    private SituacaoMapper situacaoMapper;

    public SituacaoDTO salvar(SituacaoDTO situacaoDTO) {
        var response = situacaoRepository.save(this.situacaoMapper.toEntity(situacaoDTO));
        return situacaoMapper.toDTO(response);
    }

    public SituacaoDTO editar(String id, SituacaoDTO situacaoDTO) {
        var situacao = situacaoRepository.findById(id).orElseThrow( () -> new SituacaoException("Nenhuma atribuicao encontrada!") );
        this.validateBeforeUpdate(situacaoDTO, situacao);
        var atribuicaoToBeUpdated = this.situacaoMapper.toEntity(situacaoDTO);
        situacao = this.situacaoRepository.save(atribuicaoToBeUpdated);
        return this.situacaoMapper.toDTO(situacao);
    }

    public void deletar(String id) {
        var situacao = this.getSituacao(id);
        Long amountOfCartorios = this.getAmountOfCartorios(situacao.getNome());
        if (amountOfCartorios != null && amountOfCartorios > 0) {
            throw new SituacaoException(ErrorCode.HAS_ASSOCIATED.getDescription());
        }
        situacaoRepository.delete(situacao);
    }

    public PagedResponse findById(String id, Pageable pageable) {
        var situacao = situacaoRepository.findById(id).orElseThrow( () -> new CartorioException("Nenhuma situação encontrada!"));
        var page = PageableExecutionUtils.getPage(List.of(situacao), pageable,List.of(situacao)::size);
        return this.getPageSituacoes(pageable,page);
    }

    public PagedResponse listar(Pageable pageable) {
        var situacoes = situacaoRepository.findAll();
        var page = PageableExecutionUtils.getPage(situacoes, pageable,situacoes::size);
        return this.getPageSituacoes(pageable,page);
    }

    private PagedResponse getPageSituacoes(Pageable pageable, Page page) {
        return new PagedResponse(new PageImpl<SituacaoDTO>(this.listStandardSituacoesDTO(page.toList()), pageable, page.getTotalElements()));

    }

    private List<SituacaoDTO> listStandardSituacoesDTO(List<Situacao> situacoes) {
        return situacoes
                .stream()
                .map(SituacaoMapper::toDTO)
                .collect(Collectors.toList());
    }

    private Situacao getSituacao(String id) {
        return situacaoRepository.findById(id).orElseThrow( () -> new SituacaoException("Nenhuma atribuicao encontrada!") );
    }

    private Long getAmountOfSituacoesByName(String situacao) {
        return this.situacaoRepository.findByNome(situacao).stream().count();
    }

    private Long getAmountOfSituacoesById(String id) {
        return this.situacaoRepository.findById(id).stream().count();
    }

    private Long getAmountOfCartorios(String nome) {
        return this.situacaoRepository.countCartoriosBySituacao(nome);
    }

    private void validateBeforeUpdate(SituacaoDTO situacaoDTO, Situacao situacao) {
//        if(Objects.nonNull(situacao) && this.getAmountOfSituacoesById(situacao.getId()) > 0) {
//            var exception = HandleError.getInstance().handleErrorMessage(situacaoDTO.getId(),"ID");
//            throw exception;
//        }

        if(Objects.nonNull(situacao) && this.getAmountOfSituacoesByName(situacaoDTO.getNome()) > 0) {
            var exception = HandleError.getInstance().handleErrorMessage(situacaoDTO.getNome(),"NOME");
            throw exception;
        }
    }

}
