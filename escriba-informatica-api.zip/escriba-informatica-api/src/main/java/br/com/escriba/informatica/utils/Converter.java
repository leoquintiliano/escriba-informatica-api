package br.com.escriba.informatica.utils;

public class Converter {
}
