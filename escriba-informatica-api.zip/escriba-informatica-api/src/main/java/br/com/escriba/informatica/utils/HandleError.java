package br.com.escriba.informatica.utils;

import br.com.escriba.informatica.atribuicao.message.ErrorCode;
import br.com.escriba.informatica.exception.AtribuicaoException;
import org.springframework.stereotype.Component;

@Component
public class HandleError {

    private static HandleError uniqueInstance;

    public static synchronized HandleError getInstance() {
        if(uniqueInstance == null)
            uniqueInstance = new HandleError();
        return uniqueInstance;
    }

    public AtribuicaoException handleErrorMessage(String field, String param) {
        return new AtribuicaoException(this.getParam(param).getDescription().concat("{").concat(field).concat("}") );
    }

    private ErrorCode getParam(String param) {
        return param.equals("ID") ? ErrorCode.EXISTING_ID : ErrorCode.EXISTING_NAME;
    }

}
