package br.com.escriba.informatica.utils;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collection;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PagedResponse<T> {

    private Collection<?> content;
    private PageMetadata page;

    public PagedResponse(Page<?> page) {
        this.content = page.getContent();
        this.page = new PageMetadata(page.getSize(), page.getNumber(), page.getTotalElements(), page.getTotalPages());
    }

    public PagedResponse(Collection<?> transformedItems, Page page) {
        this.content = transformedItems;
        this.page = new PageMetadata(page.getSize(), page.getNumber(), page.getTotalElements(), page.getTotalPages());
    }

    public PagedResponse(Collection<?> items, Pageable pageable, Long totalElements) {
        this.content = items;
        int totalPages = pageable.getPageNumber() > 0 ? (int) Math.ceil(totalElements / pageable.getPageNumber()) : 0;
        this.page = new PageMetadata(pageable.getPageSize(), pageable.getPageNumber(), totalElements, totalPages);
    }

    @Data
    @AllArgsConstructor
    public static class PageMetadata {
        private long size;
        private long number;
        private long totalElements;
        private long totalPages;
    }


}
