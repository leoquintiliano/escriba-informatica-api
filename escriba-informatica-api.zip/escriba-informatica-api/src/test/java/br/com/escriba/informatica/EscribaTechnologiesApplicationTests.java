package br.com.escriba.informatica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EscribaTechnologiesApplicationTests {

    @Test
    void contextLoads() {
    }

}
